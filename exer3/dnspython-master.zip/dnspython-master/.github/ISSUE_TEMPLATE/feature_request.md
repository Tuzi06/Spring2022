---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: Enhancement Request
assignees: ''

---

**Motivation**
Please describe in detail the use you have for the proposed feature, or the problem that it will solve.  This is the most important part of a feature request!

**Describe the solution you'd like.**
A clear and concise description of what you want to happen.
