.. _license:

Dnspython License
=================

.. include:: ../LICENSE
