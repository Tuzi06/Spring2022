import dns.rdtypes.txtbase

class TTXT(dns.rdtypes.txtbase.TXTBase):
    """Test TXT-like record"""
